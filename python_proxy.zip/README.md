# Flask Proxy Server

This is a simple web proxy built using Flask. It fetches content from any URL provided.

## How to Run on Replit:
1. Upload this project to Replit.
2. Install dependencies: `pip install -r requirements.txt`
3. Run the script: `python proxy.py`
4. Access the proxy: `http://your-replit-url/proxy?url=https://example.com`

## How to Deploy on Render:
1. Upload the project to GitHub.
2. Connect your GitHub repo to Render and deploy a Flask web service.
3. Set the start command to `python proxy.py`.

Enjoy your proxy! 🚀
